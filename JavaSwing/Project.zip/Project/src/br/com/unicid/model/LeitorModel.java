package br.com.unicid.model;

public class LeitorModel {
	private Integer idLeitor;
	private String nomeLeitor;
	private String tipoLeitor;
	
	public LeitorModel() {
	}

	public LeitorModel(Integer idLeitor, String nomeLeitor, String tipoLeitor) {
		this.idLeitor = idLeitor;
		this.nomeLeitor = nomeLeitor;
		this.tipoLeitor = tipoLeitor;
	}

	public Integer getIdLeitor() {
		return idLeitor;
	}

	public void setIdLeitor(Integer idLeitor) {
		this.idLeitor = idLeitor;
	}

	public String getNomeLeitor() {
		return nomeLeitor;
	}

	public void setNomeLeitor(String nomeLeitor) {
		this.nomeLeitor = nomeLeitor;
	}

	public String getTipoLeitor() {
		return tipoLeitor;
	}

	public void setTipoLeitor(String tipoLeitor) {
		this.tipoLeitor = tipoLeitor;
	}
}
