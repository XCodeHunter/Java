package br.com.unicid.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import br.com.unicid.dao.LeitorDao;
import br.com.unicid.model.LeitorModel;

public class Index extends JFrame {

	private JPanel contentPane;
	private JTextField txtCdLeitor;
	private LeitorModel leitor;
	private LeitorDao leitorDao;
	private JLabel label;
	private JTextField txtNomeLeitor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Index frame = new Index();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Index() {
		setTitle("Example");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 681, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Tipo de leitor");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(22, 118, 105, 22);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("Codigo do leitor");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(21, 28, 126, 22);
		contentPane.add(lblNewLabel_1_1);

		JLabel lblMensagem = new JLabel("");
		lblMensagem.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, Color.RED, Color.BLACK));
		lblMensagem.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMensagem.setBounds(21, 380, 595, 36);
		contentPane.add(lblMensagem);

		txtCdLeitor = new JTextField();
		txtCdLeitor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtCdLeitor.setColumns(10);
		txtCdLeitor.setBounds(174, 23, 444, 36);
		contentPane.add(txtCdLeitor);

		JComboBox ListarTipoLeitor = new JComboBox();
		ListarTipoLeitor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		ListarTipoLeitor.setModel(new DefaultComboBoxModel(
				new String[] { "Selecione uma op\u00E7\u00E3o", "Aluno\t", "Professor", "Adm" }));
		ListarTipoLeitor.setBounds(172, 114, 444, 36);
		contentPane.add(ListarTipoLeitor);

		TextArea txtListar = new TextArea();
		txtListar.setBounds(22, 192, 595, 182);
		contentPane.add(txtListar);

		JButton btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				txtCdLeitor.setText(null);
				txtNomeLeitor.setText(null);
				txtListar.setText(null);
				ListarTipoLeitor.setSelectedIndex(0);
				lblMensagem.setText(null);
			}
		});
		btnNovo.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNovo.setBounds(21, 161, 89, 23);
		contentPane.add(btnNovo);

		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				leitor = new LeitorModel();
				leitor.setIdLeitor(Integer.parseInt(txtCdLeitor.getText()));
				leitor.setNomeLeitor(txtNomeLeitor.getText());
				leitor.setTipoLeitor((String) ListarTipoLeitor.getSelectedItem());

				try {
					leitorDao = new LeitorDao();
					leitorDao.salvar(leitor);
					lblMensagem.setText("SALVO COM SUCESSO");
				} catch (Exception e2) {
					lblMensagem.setText("Erro " + e2.getMessage());
				}

				txtCdLeitor.setText(null);
				txtListar.setText(null);
				txtNomeLeitor.setText(null);
				ListarTipoLeitor.setSelectedIndex(0);

			}
		});
		btnSalvar.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnSalvar.setBounds(120, 161, 89, 23);
		contentPane.add(btnSalvar);

		JButton btnListar = new JButton("Listar");
		btnListar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtListar.setText(null);
				try {
					List<LeitorModel> list = new ArrayList<>();
					leitorDao = new LeitorDao();
					list = leitorDao.listar();

					list.forEach(f -> {
						txtListar.append("Codigo do leitor: " + f.getIdLeitor() + '\n');
						txtListar.append("Nome do leitor: " + f.getNomeLeitor() + '\n');
						txtListar.append("Tipo do leitor: " + f.getTipoLeitor() + '\n' + '\n');
					});

				} catch (Exception e2) {
					// TODO: handle exception
				}
			}
		});
		btnListar.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnListar.setBounds(219, 161, 89, 23);
		contentPane.add(btnListar);

		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				leitor = new LeitorModel();
				leitor.setIdLeitor(Integer.parseInt(txtCdLeitor.getText()));
				leitor.setNomeLeitor(txtNomeLeitor.getText());
				leitor.setTipoLeitor((String) ListarTipoLeitor.getSelectedItem());

				try {
					leitorDao = new LeitorDao();
					leitorDao.update(leitor);
					lblMensagem.setText("ALTERADO COM SUCESSO");
				} catch (Exception e2) {
					lblMensagem.setText("Erro ao alterar" + e2.getMessage());
					e2.printStackTrace();
				}

				txtCdLeitor.setText(null);
				txtListar.setText(null);
				txtNomeLeitor.setText(null);
				ListarTipoLeitor.setSelectedIndex(0);
			}
		});
		btnAlterar.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnAlterar.setBounds(318, 161, 89, 23);
		contentPane.add(btnAlterar);

		JButton btnConsultar = new JButton("Consultar");
		btnConsultar.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnConsultar.setBounds(521, 161, 105, 25);
		contentPane.add(btnConsultar);

		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					leitorDao = new LeitorDao();
					int id = Integer.parseInt(txtCdLeitor.getText());
					leitorDao.delete(id);
					lblMensagem.setText("Deletado com sucesso");
				} catch (Exception e2) {
					lblMensagem.setText("Erro ao deletar");
				}
			}
		});
		btnExcluir.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnExcluir.setBounds(417, 161, 89, 23);
		contentPane.add(btnExcluir);

		label = new JLabel("Nome do leitor");
		label.setFont(new Font("Tahoma", Font.PLAIN, 18));
		label.setBounds(22, 76, 117, 22);
		contentPane.add(label);

		txtNomeLeitor = new JTextField();
		txtNomeLeitor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtNomeLeitor.setColumns(10);
		txtNomeLeitor.setBounds(175, 71, 444, 36);
		contentPane.add(txtNomeLeitor);

	}
}
