package br.com.unicid.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.com.unicid.ConnectionFactory;
import br.com.unicid.model.LeitorModel;

public class LeitorDao {

	private Connection connection;
	
	@SuppressWarnings("static-access")
	public LeitorDao() {
		try {
			connection = new ConnectionFactory().criaConexao();
			
		} catch (Exception e) {
		}
		
	}

	public List<LeitorModel> listar(){
		try {
			List<LeitorModel> leitorList = new ArrayList<>();
			String sql = "SELECT idLeitor, nomeLeitor, tipoLeitor FROM leitor";
			
			try (PreparedStatement pstm = connection.prepareStatement(sql)) {
				pstm.execute();
				
				try (ResultSet rst = pstm.getResultSet()) {
					while (rst.next()) {
						LeitorModel leitor = new LeitorModel(rst.getInt(1), rst.getString(2), rst.getString(3));
						
						leitorList.add(leitor);
					}
				}
			}
			return leitorList;
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		
	}

	public void salvar(LeitorModel leitor)  {	
		try {
			String sql = "INSERT INTO leitor (nomeLeitor, tipoLeitor) VALUES (?, ?)";
			try (PreparedStatement pstm = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
				
				pstm.setString(1, leitor.getNomeLeitor());
				pstm.setString(2, leitor.getTipoLeitor());
				
				pstm.execute();
				
				try (ResultSet rst = pstm.getGeneratedKeys()) {
					while (rst.next()) {
						leitor.setIdLeitor(rst.getInt(1));
					}
				}
			}
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void update(LeitorModel leitor)  {	
		try {
			String sql = "UPDATE leitor SET nomeLeitor=?, tipoLeitor=? WHERE idLeitor=?";
			try (PreparedStatement pstm = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
				
				pstm.setString(1, leitor.getNomeLeitor());
				pstm.setString(2, leitor.getTipoLeitor());
				pstm.setInt(3, leitor.getIdLeitor());
				pstm.executeUpdate();
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void delete(int idleitor)  {	
		try {
			String sql = "DELETE FROM leitor WHERE idLeitor=?";
			try (PreparedStatement pstm = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

				pstm.setInt(1, idleitor);
				pstm.executeUpdate();
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
}
